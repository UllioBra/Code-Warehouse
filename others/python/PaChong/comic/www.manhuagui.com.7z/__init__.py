import os
def AK():
    print("WSY and XJH AK!")

if __name__ == '__main__':
    AK()
    os.system('python -m pip install requests selenium bs4')
