clang++  juruo.cpp -o juruo
clang++  std.cpp -o std