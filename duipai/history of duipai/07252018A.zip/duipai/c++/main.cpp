#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <fstream>
using namespace std;

int main(int argc, char const *argv[]) {
	printf("First:make\nSecond:std\nThird:your code(juruo)\n(The APP is for linux)\n");

	// while(1) {
	// 	system("./make>/pre/tmp.in");
	// 	system(".//pre/std<tmp.in>std.out");
	// 	system(".//pre/juro<tmp.in>juruo.out");
	// 	bool st=system("diff /pre/std.out /pre/juruo.out");
	// 	if(st==1) printf("WA\n");
	// 	else printf("AC\n");
	// 	system("echo 'Next?' ");
	// }

	while(1) {
		
	}
	
	return 0;
}