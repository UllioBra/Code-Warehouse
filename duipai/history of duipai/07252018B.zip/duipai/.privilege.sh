
chmod -R a+rwx *
chmod -R a=rw ./pre/*.cpp
chmod -R a=rw ./c++/*.cpp
chmod -R a=rw *.in
chmod -R a=rw *.out