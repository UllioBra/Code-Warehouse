clang++ -g -std=c++11 std.cpp -o std
clang++ -g -std=c++11 juruo.cpp -o juruo